package com.example.krrabota

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class LoginRegistration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_registration)
    }

    fun login(view: View) {
        val intent = Intent(this@LoginRegistration,Sign::class.java)
        startActivity(intent)
        finish()
    }

    fun registration(view: View) {
        val intent = Intent(this@LoginRegistration,Registration::class.java)
        startActivity(intent)
        finish()
    }
}