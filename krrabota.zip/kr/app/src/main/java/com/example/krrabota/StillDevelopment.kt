package com.example.krrabota

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class StillDevelopment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_still_development)
    }
}